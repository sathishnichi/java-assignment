package com.main.about;


public interface Resturant {
         public String foodType="Veg";
         public String food="nonVeg";
         
       public void  Vegbuff();
       
       public void  nonvegbuff();
      
}
