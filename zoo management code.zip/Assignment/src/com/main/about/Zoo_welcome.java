package com.main.about;

public interface Zoo_welcome {
 String welcome(String zooname);
}
